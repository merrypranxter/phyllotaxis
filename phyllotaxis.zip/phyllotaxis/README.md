# phyllotaxis

A creative coding project exploring **phyllotaxis** — the spiral packing of seeds, scales, and florets ruled by the golden angle 137.507°. Vogel's model drops point n at angle n·137.5° and radius √n, and the Fibonacci numbers fall out of the visible spiral arms.

**Distinct from `botanical_illustration`:** the math of arrangement, not plant rendering.

## What Is Phyllotaxis?

The arrangement of repeated units (seeds, leaves, florets) on a plant. The golden angle ≈ 137.507° produces the densest packing. Vogel's model: `θ = n·137.507°`, `r = c·√n`. The visible spiral arms (parastichies) count consecutive Fibonacci numbers — that's the signature.

## Project Structure

```
src/
  js/
    main.js           — WebGL setup, render loop, parameter UI
    color-maps.js     — 256px ramps
  shaders/
    arrangements/     — swappable engines
      vogel-disk.glsl      — θ = n·137.507°, r = c·√n
      fibonacci-sphere.glsl — golden-angle sphere distribution
      conical.glsl         — pinecone / cylindrical
      parametric-angle.glsl — sweepable divergence angle
    floret.vert       — instance n → position from golden angle
    floret.frag       — color by n / parastichy
    post-process.frag — bloom
```

## Current Engines

- [ ] _vogel_disk — the sunflower, golden angle on a plane
- [ ] _fibonacci_sphere — even sphere distribution via golden angle
- [ ] _conical — pinecone / cylindrical phyllotaxis
- [ ] _parametric_angle — sweepable divergence angle (interactive heart)

## Aesthetic Regimes

- [ ] sunflower_classic — golden angle, brown-gold florets, 1,597 seeds
- [ ] angle_sweep — sweep 137°→138°, spirals unwind and reform, hypnotic neon
- [ ] succulent_jewel — 3D conical, iridescent fleshy scales
- [ ] fibonacci_sphere_swarm — even sphere distribution, glowing points, rotating

## Parameters

- `point_count_N` — e.g. 1,597 (a Fibonacci number)
- `divergence_angle` — 137.507° (make it sweepable)
- `radius_scale` — density control
- `mode` — disk | sphere | cone
- `floret_shape` — disc | scale | point

## Ecosystem Hooks

Cousin `botanical_illustration` (flag distinct). Pairs with `sacred_geometry`, `fractals`. Shading borrows `structural_color`.

---

*137.507°. The number that makes the spirals count themselves.*
