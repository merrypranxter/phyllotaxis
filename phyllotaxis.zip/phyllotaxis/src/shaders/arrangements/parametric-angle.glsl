// TODO: arrangements/parametric-angle.glsl
