// TODO: arrangements/vogel-disk.glsl
