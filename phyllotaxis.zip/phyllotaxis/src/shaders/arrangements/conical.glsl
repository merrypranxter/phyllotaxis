// TODO: arrangements/conical.glsl
