// TODO: arrangements/fibonacci-sphere.glsl
